ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "source_payload" jsonb;
