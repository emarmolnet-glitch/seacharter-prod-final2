CREATE TABLE IF NOT EXISTS "vessel_learning_history" (
	"id" serial PRIMARY KEY,
	"imo_number" integer,
	"vessel_name" text DEFAULT 'N/A',
	"port_name" text DEFAULT 'N/A' NOT NULL,
	"eta_radar" timestamp,
	"eta_validated" timestamp,
	"delta_hours" numeric(10,2) NOT NULL,
	"delta_days" numeric(10,2) NOT NULL,
	"source_action" text DEFAULT 'MANUAL' NOT NULL,
	"payload" jsonb,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "validation_status" text DEFAULT 'PENDIENTE' NOT NULL;--> statement-breakpoint
ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "external_vessel_status" text;--> statement-breakpoint
ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "external_validation_checked_at" timestamp;
