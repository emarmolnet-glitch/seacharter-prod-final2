ALTER TABLE "vessels_blacklist" ADD COLUMN IF NOT EXISTS "system_identity" text;--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "vessels_blacklist_system_identity_idx" ON "vessels_blacklist" ("system_identity");
