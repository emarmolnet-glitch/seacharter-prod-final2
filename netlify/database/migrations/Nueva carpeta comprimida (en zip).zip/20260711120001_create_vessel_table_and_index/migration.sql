CREATE TABLE IF NOT EXISTS "Vessel" (
	"id" serial PRIMARY KEY,
	"nombre" text NOT NULL,
	"imo" text NOT NULL,
	"dwt" text,
	"origen" text DEFAULT 'Shipnext-Extension' NOT NULL,
	"createdAt" timestamp(3) DEFAULT now() NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS "Vessel_imo_key" ON "Vessel" ("imo");
