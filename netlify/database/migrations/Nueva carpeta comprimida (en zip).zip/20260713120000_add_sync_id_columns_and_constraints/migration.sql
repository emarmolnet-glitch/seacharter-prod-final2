ALTER TABLE "session_sync" ADD COLUMN IF NOT EXISTS "sync_id" text;
ALTER TABLE "ia_reports" ADD COLUMN IF NOT EXISTS "sync_id" text;

UPDATE "session_sync"
SET "sync_id" = 'legacy-' || md5("user_id")
WHERE "sync_id" IS NULL;

UPDATE "ia_reports" AS reports
SET "sync_id" = COALESCE(
  (SELECT syncs."sync_id" FROM "session_sync" AS syncs WHERE syncs."user_id" = reports."user_id"),
  'legacy-' || md5(reports."user_id")
)
WHERE reports."sync_id" IS NULL;

ALTER TABLE "session_sync" ALTER COLUMN "sync_id" SET NOT NULL;
ALTER TABLE "ia_reports" ALTER COLUMN "sync_id" SET NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS "session_sync_sync_id_unique" ON "session_sync" ("sync_id");
CREATE UNIQUE INDEX IF NOT EXISTS "ia_reports_sync_id_unique" ON "ia_reports" ("sync_id");
