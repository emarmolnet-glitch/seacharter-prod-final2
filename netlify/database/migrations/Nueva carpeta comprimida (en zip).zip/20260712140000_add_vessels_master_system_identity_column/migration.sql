ALTER TABLE "vessels_master"
  ADD COLUMN IF NOT EXISTS "system_identity" text;

CREATE UNIQUE INDEX IF NOT EXISTS "vessels_master_system_identity_key"
  ON "vessels_master" ("system_identity")
  WHERE "system_identity" IS NOT NULL
    AND "system_identity" <> ''
    AND ("imo_number" IS NULL OR "imo_number" = 0)
    AND ("mmsi" IS NULL OR "mmsi" = '');
