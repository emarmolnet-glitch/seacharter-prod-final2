CREATE TABLE "vessels_blacklist" (
	"id" serial PRIMARY KEY,
	"imo_number" integer,
	"vessel_name" text,
	"mmsi" varchar(20),
	"created_at" timestamp DEFAULT now() NOT NULL
);
