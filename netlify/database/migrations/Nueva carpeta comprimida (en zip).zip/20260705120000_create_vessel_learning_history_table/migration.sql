CREATE TABLE IF NOT EXISTS "vessel_learning_history" (
  "id" serial PRIMARY KEY,
  "imo_number" integer,
  "vessel_name" text DEFAULT 'N/A',
  "port_name" text DEFAULT 'N/A' NOT NULL,
  "eta_radar" timestamp,
  "eta_validated" timestamp,
  "delta_hours" numeric(10, 2) NOT NULL,
  "delta_days" numeric(10, 2) NOT NULL,
  "source_action" text DEFAULT 'MANUAL' NOT NULL,
  "payload" jsonb,
  "created_at" timestamp DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "vessel_learning_history_port_idx" ON "vessel_learning_history" ("port_name");
CREATE INDEX IF NOT EXISTS "vessel_learning_history_imo_idx" ON "vessel_learning_history" ("imo_number");
CREATE INDEX IF NOT EXISTS "vessel_learning_history_created_at_idx" ON "vessel_learning_history" ("created_at");
