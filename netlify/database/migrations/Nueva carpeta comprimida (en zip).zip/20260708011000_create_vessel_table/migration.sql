CREATE TABLE IF NOT EXISTS "Vessel" (
  "id" SERIAL PRIMARY KEY,
  "nombre" TEXT NOT NULL,
  "imo" TEXT NOT NULL,
  "dwt" TEXT,
  "origen" TEXT NOT NULL DEFAULT 'Shipnext-Extension',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS "Vessel_imo_key" ON "Vessel" ("imo");
