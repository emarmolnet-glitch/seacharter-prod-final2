ALTER TABLE "vessels_master"
  ALTER COLUMN "detected_at" SET DATA TYPE timestamp with time zone USING "detected_at" AT TIME ZONE 'UTC',
  ALTER COLUMN "eta_calculated_at" SET DATA TYPE timestamp with time zone USING "eta_calculated_at" AT TIME ZONE 'UTC',
  ALTER COLUMN "eta" SET DATA TYPE timestamp with time zone USING "eta" AT TIME ZONE 'UTC',
  ALTER COLUMN "fecha_ultima_actualizacion" SET DATA TYPE timestamp with time zone USING "fecha_ultima_actualizacion" AT TIME ZONE 'UTC',
  ALTER COLUMN "audited_at" SET DATA TYPE timestamp with time zone USING "audited_at" AT TIME ZONE 'UTC',
  ALTER COLUMN "external_validation_checked_at" SET DATA TYPE timestamp with time zone USING "external_validation_checked_at" AT TIME ZONE 'UTC';
