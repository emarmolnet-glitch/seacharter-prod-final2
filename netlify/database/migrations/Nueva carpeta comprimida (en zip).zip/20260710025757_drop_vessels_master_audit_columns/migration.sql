DROP TABLE "audit_pending_vessels";--> statement-breakpoint
DROP TABLE "vessel_audit_job_items";--> statement-breakpoint
DROP TABLE "vessel_audit_jobs";--> statement-breakpoint
DROP TABLE "vessel_learning_history";--> statement-breakpoint
ALTER TABLE "vessels_master" DROP COLUMN "audit_status";--> statement-breakpoint
ALTER TABLE "vessels_master" DROP COLUMN "audit_source";--> statement-breakpoint
ALTER TABLE "vessels_master" DROP COLUMN "log_correccion";--> statement-breakpoint
ALTER TABLE "vessels_master" DROP COLUMN "audited_at";--> statement-breakpoint
ALTER TABLE "vessels_master" DROP COLUMN "validation_status";--> statement-breakpoint
ALTER TABLE "vessels_master" DROP COLUMN "external_vessel_status";--> statement-breakpoint
ALTER TABLE "vessels_master" DROP COLUMN "external_validation_checked_at";