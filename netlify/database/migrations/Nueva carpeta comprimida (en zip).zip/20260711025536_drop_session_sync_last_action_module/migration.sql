CREATE TABLE "ia_reports" (
	"user_id" text PRIMARY KEY,
	"report_data" jsonb NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "session_sync" DROP COLUMN "last_action_module";