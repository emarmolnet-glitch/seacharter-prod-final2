CREATE TABLE IF NOT EXISTS "session_sync" (
	"user_id" text PRIMARY KEY,
	"last_sync_data" jsonb NOT NULL,
	"last_action_module" text NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
