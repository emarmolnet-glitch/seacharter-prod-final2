CREATE TABLE IF NOT EXISTS "port_tariff_rules" (
  "port_id" text PRIMARY KEY,
  "currency" varchar(3) NOT NULL,
  "rules" jsonb NOT NULL,
  "source_filename" text,
  "created_at" timestamp DEFAULT now() NOT NULL,
  "updated_at" timestamp DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "port_tariff_rules_currency_idx" ON "port_tariff_rules" ("currency");
