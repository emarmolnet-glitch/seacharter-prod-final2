ALTER TABLE "vessels_master" ADD COLUMN "flag" varchar(3);--> statement-breakpoint
ALTER TABLE "vessels_master" ADD COLUMN "vessel_type" text;--> statement-breakpoint
ALTER TABLE "vessels_master" ADD COLUMN "year_built" integer;