ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "process_status" text;--> statement-breakpoint
ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "current_destination" text;
