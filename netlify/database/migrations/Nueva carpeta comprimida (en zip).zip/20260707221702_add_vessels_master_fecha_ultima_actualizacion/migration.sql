ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "fecha_ultima_actualizacion" timestamp;--> statement-breakpoint
ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "origen" text;
