ALTER TABLE "Vessel" ADD COLUMN IF NOT EXISTS "mmsi" varchar(20);
ALTER TABLE "Vessel" ALTER COLUMN "imo" DROP NOT NULL;
UPDATE "Vessel" SET "imo" = NULL WHERE trim("imo") = '';
DROP INDEX IF EXISTS "Vessel_imo_key";
CREATE UNIQUE INDEX IF NOT EXISTS "Vessel_valid_imo_key"
  ON "Vessel" ("imo")
  WHERE "imo" IS NOT NULL AND "imo" <> '0';
CREATE UNIQUE INDEX IF NOT EXISTS "Vessel_unknown_imo_mmsi_key"
  ON "Vessel" ("mmsi")
  WHERE "mmsi" IS NOT NULL AND "mmsi" <> '' AND ("imo" IS NULL OR "imo" = '0');

ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "id" serial;
ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "mmsi" varchar(20);
ALTER TABLE "vessels_master" DROP CONSTRAINT IF EXISTS "vessels_master_pkey";
ALTER TABLE "vessels_master" ALTER COLUMN "imo_number" DROP NOT NULL;
ALTER TABLE "vessels_master" ALTER COLUMN "id" SET NOT NULL;
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conrelid = '"vessels_master"'::regclass
      AND contype = 'p'
  ) THEN
    ALTER TABLE "vessels_master" ADD CONSTRAINT "vessels_master_pkey" PRIMARY KEY ("id");
  END IF;
END $$;
CREATE UNIQUE INDEX IF NOT EXISTS "vessels_master_valid_imo_key"
  ON "vessels_master" ("imo_number")
  WHERE "imo_number" IS NOT NULL AND "imo_number" <> 0;
CREATE UNIQUE INDEX IF NOT EXISTS "vessels_master_unknown_imo_mmsi_key"
  ON "vessels_master" ("mmsi")
  WHERE "mmsi" IS NOT NULL AND "mmsi" <> '' AND ("imo_number" IS NULL OR "imo_number" = 0);
