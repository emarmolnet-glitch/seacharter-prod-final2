-- Superseded by 20260705213313_create_app_state_table.
SELECT 1;
