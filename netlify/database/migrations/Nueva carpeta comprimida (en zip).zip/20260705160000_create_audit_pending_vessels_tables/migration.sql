CREATE TABLE IF NOT EXISTS "audit_pending_vessels" (
  "id" serial PRIMARY KEY,
  "imo" text NOT NULL,
  "vessel_name" text NOT NULL,
  "eta_puerto_carga" text NOT NULL,
  "status" text DEFAULT 'PENDING' NOT NULL,
  "payload" jsonb NOT NULL,
  "received_at" timestamp DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "audit_pending_vessels_status_idx" ON "audit_pending_vessels" ("status");
CREATE INDEX IF NOT EXISTS "audit_pending_vessels_imo_idx" ON "audit_pending_vessels" ("imo");
