ALTER TABLE "vessels_blacklist" DROP CONSTRAINT "vessels_blacklist_pkey";--> statement-breakpoint
ALTER TABLE "vessels_blacklist" DROP COLUMN "id";--> statement-breakpoint
ALTER TABLE "vessels_master" DROP COLUMN "eta_puerto_carga";