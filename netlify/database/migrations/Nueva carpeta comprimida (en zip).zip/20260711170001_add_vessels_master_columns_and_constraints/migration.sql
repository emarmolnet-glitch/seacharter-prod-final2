ALTER TABLE "Vessel" ADD COLUMN IF NOT EXISTS "mmsi" varchar(20);--> statement-breakpoint
ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "id" serial;--> statement-breakpoint
ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "mmsi" varchar(20);--> statement-breakpoint
ALTER TABLE "Vessel" ALTER COLUMN "imo" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "vessels_master" ALTER COLUMN "imo_number" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "vessels_master" ALTER COLUMN "id" SET NOT NULL;--> statement-breakpoint
DROP INDEX IF EXISTS "Vessel_imo_key";--> statement-breakpoint
DO $$
BEGIN
	IF NOT EXISTS (
		SELECT 1
		FROM pg_constraint
		WHERE conrelid = '"vessels_master"'::regclass
			AND contype = 'p'
	) THEN
		ALTER TABLE "vessels_master" ADD CONSTRAINT "vessels_master_pkey" PRIMARY KEY ("id");
	END IF;
END $$;--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "Vessel_valid_imo_key" ON "Vessel" ("imo") WHERE "imo" is not null and "imo" <> '0';--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "Vessel_unknown_imo_mmsi_key" ON "Vessel" ("mmsi") WHERE "mmsi" is not null and "mmsi" <> '' and ("imo" is null or "imo" = '0');--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "vessels_master_valid_imo_key" ON "vessels_master" ("imo_number") WHERE "imo_number" is not null and "imo_number" <> 0;--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "vessels_master_unknown_imo_mmsi_key" ON "vessels_master" ("mmsi") WHERE "mmsi" is not null and "mmsi" <> '' and ("imo_number" is null or "imo_number" = 0);
