CREATE TABLE IF NOT EXISTS "audit_pending_vessels" (
  "id" serial PRIMARY KEY,
  "imo" text,
  "vessel_name" text NOT NULL,
  "eta_puerto_carga" text,
  "status" text DEFAULT 'PENDING' NOT NULL,
  "payload" jsonb NOT NULL,
  "received_at" timestamp DEFAULT now() NOT NULL
);

ALTER TABLE "audit_pending_vessels" ADD COLUMN IF NOT EXISTS "imo" text;
ALTER TABLE "audit_pending_vessels" ADD COLUMN IF NOT EXISTS "vessel_name" text;
ALTER TABLE "audit_pending_vessels" ADD COLUMN IF NOT EXISTS "eta_puerto_carga" text;
ALTER TABLE "audit_pending_vessels" ADD COLUMN IF NOT EXISTS "status" text DEFAULT 'PENDING';
ALTER TABLE "audit_pending_vessels" ADD COLUMN IF NOT EXISTS "payload" jsonb;
ALTER TABLE "audit_pending_vessels" ADD COLUMN IF NOT EXISTS "received_at" timestamp DEFAULT now();

UPDATE "audit_pending_vessels"
SET
  "vessel_name" = COALESCE(
    NULLIF("vessel_name", ''),
    NULLIF("payload"->>'vesselName', ''),
    NULLIF("payload"->>'name', ''),
    'N/A'
  ),
  "status" = COALESCE(NULLIF("status", ''), 'PENDING'),
  "payload" = COALESCE("payload", '{}'::jsonb),
  "received_at" = COALESCE("received_at", now());

ALTER TABLE "audit_pending_vessels" ALTER COLUMN "imo" DROP NOT NULL;
ALTER TABLE "audit_pending_vessels" ALTER COLUMN "eta_puerto_carga" DROP NOT NULL;
ALTER TABLE "audit_pending_vessels" ALTER COLUMN "vessel_name" SET NOT NULL;
ALTER TABLE "audit_pending_vessels" ALTER COLUMN "status" SET DEFAULT 'PENDING';
ALTER TABLE "audit_pending_vessels" ALTER COLUMN "status" SET NOT NULL;
ALTER TABLE "audit_pending_vessels" ALTER COLUMN "payload" SET NOT NULL;
ALTER TABLE "audit_pending_vessels" ALTER COLUMN "received_at" SET DEFAULT now();
ALTER TABLE "audit_pending_vessels" ALTER COLUMN "received_at" SET NOT NULL;

CREATE INDEX IF NOT EXISTS "audit_pending_vessels_status_idx" ON "audit_pending_vessels" ("status");
CREATE INDEX IF NOT EXISTS "audit_pending_vessels_imo_idx" ON "audit_pending_vessels" ("imo");
CREATE INDEX IF NOT EXISTS "audit_pending_vessels_received_at_idx" ON "audit_pending_vessels" ("received_at");
