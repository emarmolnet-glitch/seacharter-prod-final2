DROP INDEX IF EXISTS "vessels_master_valid_imo_key";--> statement-breakpoint
DROP INDEX IF EXISTS "vessels_master_unknown_imo_mmsi_key";--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "vessels_master_valid_imo_mmsi_key"
ON "vessels_master" ("imo_number", "mmsi")
WHERE "imo_number" IS NOT NULL AND "imo_number" <> 0;
