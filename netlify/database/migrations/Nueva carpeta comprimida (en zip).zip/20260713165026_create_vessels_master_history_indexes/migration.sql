CREATE TABLE IF NOT EXISTS "vessels_master_history" (
	"id" serial PRIMARY KEY,
	"vessel_id" integer NOT NULL,
	"identity_key" text NOT NULL,
	"snapshot" jsonb NOT NULL,
	"source_payload" jsonb,
	"source_updated_at" timestamp with time zone,
	"origin" text,
	"received_at" timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "vessels_master_updated_at_id_idx" ON "vessels_master" ("fecha_ultima_actualizacion" DESC NULLS LAST,"id" DESC);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "vessels_master_history_received_at_id_idx" ON "vessels_master_history" ("received_at" DESC,"id" DESC);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "vessels_master_history_identity_received_at_idx" ON "vessels_master_history" ("identity_key","received_at" DESC,"id" DESC);
