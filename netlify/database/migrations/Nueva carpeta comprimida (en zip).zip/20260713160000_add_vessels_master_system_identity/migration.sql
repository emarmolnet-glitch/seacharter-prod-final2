ALTER TABLE "vessels_master"
  ADD COLUMN IF NOT EXISTS "system_identity" text;

CREATE UNIQUE INDEX IF NOT EXISTS "vessels_master_system_identity_key"
  ON "vessels_master" ("system_identity")
  WHERE "system_identity" IS NOT NULL
    AND "system_identity" <> ''
    AND ("imo_number" IS NULL OR "imo_number" = 0)
    AND ("mmsi" IS NULL OR "mmsi" = '');

CREATE INDEX IF NOT EXISTS "vessels_master_updated_at_id_idx"
  ON "vessels_master" ("fecha_ultima_actualizacion" DESC NULLS LAST, "id" DESC);

CREATE TABLE IF NOT EXISTS "vessels_master_history" (
  "id" serial PRIMARY KEY,
  "vessel_id" integer NOT NULL,
  "identity_key" text NOT NULL,
  "snapshot" jsonb NOT NULL,
  "source_payload" jsonb,
  "source_updated_at" timestamp with time zone,
  "origin" text,
  "received_at" timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);

CREATE INDEX IF NOT EXISTS "vessels_master_history_received_at_id_idx"
  ON "vessels_master_history" ("received_at" DESC, "id" DESC);

CREATE INDEX IF NOT EXISTS "vessels_master_history_identity_received_at_idx"
  ON "vessels_master_history" ("identity_key", "received_at" DESC, "id" DESC);
