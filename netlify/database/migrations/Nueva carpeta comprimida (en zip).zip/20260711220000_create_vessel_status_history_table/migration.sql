CREATE TABLE "vessel_status_history" (
	"id" serial PRIMARY KEY,
	"vessel_id" integer NOT NULL,
	"previous_status" text NOT NULL,
	"new_status" text NOT NULL,
	"changed_by_user_id" text NOT NULL,
	"changed_by_email" text,
	"changed_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "vessel_status_history_vessel_changed_at_idx" ON "vessel_status_history" ("vessel_id","changed_at");--> statement-breakpoint
CREATE INDEX "vessel_status_history_user_changed_at_idx" ON "vessel_status_history" ("changed_by_user_id","changed_at");--> statement-breakpoint
ALTER TABLE "vessel_status_history" ADD CONSTRAINT "vessel_status_history_vessel_id_vessels_master_id_fkey" FOREIGN KEY ("vessel_id") REFERENCES "vessels_master"("id") ON DELETE CASCADE;