-- Superseded by 20260629120000_create_vessel_audit_jobs_tables,
-- which creates the same tables idempotently and includes the index.
SELECT 1;
