ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "last_port" text;
