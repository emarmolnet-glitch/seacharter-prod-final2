ALTER TABLE "vessels_master" ADD COLUMN "draft_meters" numeric(6, 2);
ALTER TABLE "vessels_master" ADD COLUMN "eta_calculated_at" timestamp;
ALTER TABLE "vessels_master" ADD COLUMN "eta" timestamp;
ALTER TABLE "vessels_master" ADD COLUMN "days_outside_window" numeric(8, 2);
ALTER TABLE "vessels_master" ADD COLUMN "deviation_cost" numeric(14, 2);
ALTER TABLE "vessels_master" ADD COLUMN "audit_status" text DEFAULT 'PENDING' NOT NULL;
ALTER TABLE "vessels_master" ADD COLUMN "audit_source" text;
ALTER TABLE "vessels_master" ADD COLUMN "log_correccion" jsonb;
ALTER TABLE "vessels_master" ADD COLUMN "audited_at" timestamp;
