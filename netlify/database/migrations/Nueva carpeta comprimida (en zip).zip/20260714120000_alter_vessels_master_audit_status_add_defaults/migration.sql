ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "audit_status" text;
--> statement-breakpoint
UPDATE "vessels_master"
SET "audit_status" = CASE
  WHEN "status" IN ('APPROVED', 'REJECTED', 'SYNCED', 'PROCESADO') THEN "status"
  ELSE 'REQUIRES_USER_REVIEW'
END
WHERE "audit_status" IS NULL;
--> statement-breakpoint
ALTER TABLE "vessels_master" ALTER COLUMN "audit_status" SET DEFAULT 'REQUIRES_USER_REVIEW';
--> statement-breakpoint
ALTER TABLE "vessels_master" ALTER COLUMN "audit_status" SET NOT NULL;
