CREATE TABLE "vessels_master" (
	"imo_number" integer PRIMARY KEY,
	"vessel_name" text DEFAULT 'N/A',
	"dwt" integer,
	"has_gears" boolean,
	"status" text DEFAULT 'PENDING' NOT NULL,
	"detected_at" timestamp DEFAULT now() NOT NULL
);
