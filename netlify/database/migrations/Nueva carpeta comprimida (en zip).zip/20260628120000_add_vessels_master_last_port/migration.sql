-- Superseded by 20260628140127_add_vessels_master_last_port.
SELECT 1;
