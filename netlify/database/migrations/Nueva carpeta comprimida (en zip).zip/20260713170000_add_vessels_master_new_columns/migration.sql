ALTER TABLE "vessels_master"
  ADD COLUMN IF NOT EXISTS "process_status" text;

ALTER TABLE "vessels_master"
  ADD COLUMN IF NOT EXISTS "system_identity" text;

ALTER TABLE "vessels_master"
  ADD COLUMN IF NOT EXISTS "current_destination" text;
