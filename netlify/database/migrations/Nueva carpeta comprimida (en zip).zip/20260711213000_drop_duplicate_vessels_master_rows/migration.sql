DROP INDEX IF EXISTS "vessels_master_valid_imo_mmsi_key";

WITH ranked AS (
  SELECT
    id,
    row_number() OVER (
      PARTITION BY imo_number
      ORDER BY
        CASE status
          WHEN 'APPROVED' THEN 5
          WHEN 'REJECTED' THEN 4
          WHEN 'PROCESADO' THEN 3
          WHEN 'SYNCED' THEN 2
          ELSE 1
        END DESC,
        fecha_ultima_actualizacion DESC NULLS LAST,
        detected_at DESC NULLS LAST,
        id DESC
    ) AS position
  FROM vessels_master
  WHERE imo_number IS NOT NULL AND imo_number <> 0
)
DELETE FROM vessels_master
WHERE id IN (SELECT id FROM ranked WHERE position > 1);

WITH ranked AS (
  SELECT
    id,
    row_number() OVER (
      PARTITION BY mmsi
      ORDER BY
        fecha_ultima_actualizacion DESC NULLS LAST,
        detected_at DESC NULLS LAST,
        id DESC
    ) AS position
  FROM vessels_master
  WHERE mmsi IS NOT NULL
    AND mmsi <> ''
    AND (imo_number IS NULL OR imo_number = 0)
)
DELETE FROM vessels_master
WHERE id IN (SELECT id FROM ranked WHERE position > 1);

CREATE UNIQUE INDEX IF NOT EXISTS "vessels_master_valid_imo_key"
  ON "vessels_master" ("imo_number")
  WHERE "imo_number" IS NOT NULL AND "imo_number" <> 0;

CREATE UNIQUE INDEX IF NOT EXISTS "vessels_master_unknown_imo_mmsi_key"
  ON "vessels_master" ("mmsi")
  WHERE "mmsi" IS NOT NULL
    AND "mmsi" <> ''
    AND ("imo_number" IS NULL OR "imo_number" = 0);
