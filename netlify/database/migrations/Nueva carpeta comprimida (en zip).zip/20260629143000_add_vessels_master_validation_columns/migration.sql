ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "validation_status" text DEFAULT 'PENDIENTE' NOT NULL;
ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "external_vessel_status" text;
ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "external_validation_checked_at" timestamp;
