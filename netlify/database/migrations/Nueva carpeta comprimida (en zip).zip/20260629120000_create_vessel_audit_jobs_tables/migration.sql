CREATE TABLE IF NOT EXISTS "vessel_audit_jobs" (
  "id" text PRIMARY KEY,
  "status" text DEFAULT 'QUEUED' NOT NULL,
  "total" integer DEFAULT 0 NOT NULL,
  "completed" integer DEFAULT 0 NOT NULL,
  "failed" integer DEFAULT 0 NOT NULL,
  "message" text,
  "created_at" timestamp DEFAULT now() NOT NULL,
  "updated_at" timestamp DEFAULT now() NOT NULL,
  "finished_at" timestamp
);

CREATE TABLE IF NOT EXISTS "vessel_audit_job_items" (
  "id" serial PRIMARY KEY,
  "job_id" text NOT NULL REFERENCES "vessel_audit_jobs"("id") ON DELETE CASCADE,
  "imo_number" integer,
  "vessel_name" text,
  "status" text DEFAULT 'QUEUED' NOT NULL,
  "message" text,
  "result" jsonb,
  "created_at" timestamp DEFAULT now() NOT NULL,
  "updated_at" timestamp DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "vessel_audit_job_items_job_id_idx" ON "vessel_audit_job_items" ("job_id");
