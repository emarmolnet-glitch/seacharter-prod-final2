ALTER TABLE "audit_pending_vessels" ALTER COLUMN "imo" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "audit_pending_vessels" ALTER COLUMN "eta_puerto_carga" DROP NOT NULL;