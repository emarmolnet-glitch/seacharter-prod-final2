ALTER TABLE "vessels_blacklist" ADD COLUMN "system_identity" text;
CREATE INDEX "vessels_blacklist_system_identity_idx" ON "vessels_blacklist" ("system_identity");
