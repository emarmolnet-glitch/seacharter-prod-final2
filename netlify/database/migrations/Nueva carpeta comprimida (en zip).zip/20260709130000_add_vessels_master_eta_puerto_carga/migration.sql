ALTER TABLE "vessels_master" ADD COLUMN IF NOT EXISTS "eta_puerto_carga" text;
