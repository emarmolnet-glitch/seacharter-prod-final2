ALTER TABLE "session_sync" DROP COLUMN IF EXISTS "last_action_module";

CREATE TABLE IF NOT EXISTS "ia_reports" (
	"user_id" text PRIMARY KEY,
	"report_data" jsonb NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
